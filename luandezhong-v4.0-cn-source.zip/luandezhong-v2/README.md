# 乱的钟 V4.0（中国大陆版）

面向三星 S23 Ultra / One UI 8.5 的 Android 桌面时钟与天气小组件。默认布局 4×3，桌面组件背景完全透明。

## 功能
- 简体中文时间、星期、完整年月日；支持 12/24 小时制。
- 时间、星期、日期、天气分别调整字号和位置；预览中拖动元素，双指缩放当前选中元素。
- 每项支持 HEX 渐变起止色和渐变方向。
- 天气优先尝试和风天气 7 天天气接口；配置有效 API Key 后使用。
- 和风天气不可用或未配置 Key 时，自动使用 Open-Meteo 7 天预报。
- 中文城市手动输入；用户主动点击定位按钮后才申请大致位置权限。拒绝权限不影响手动城市搜索。
- 摄氏度显示，网络或城市查询失败时显示错误提示。

## 国内天气 API Key
在应用内输入和风天气 API Key。需要自行在和风天气开发者平台申请并遵守其服务条款、配额和使用限制。未配置 Key 时会自动使用 Open-Meteo 备用源。

## 云端编译（GitHub Actions）
1. 将本压缩包解压。
2. 把解压后 `luandezhong-v2` 文件夹里的全部内容（包括隐藏的 `.github` 文件夹）上传到 GitHub 仓库根目录。
3. 打开仓库的 **Actions** 页面，选择 **Build 乱的钟 Android APK**。
4. 点击 **Run workflow**，等待任务完成。
5. 打开成功的工作流记录，在 **Artifacts** 下载 `luandezhong-v4-debug-apk`，解压后安装 `app-debug.apk`。

## 构建环境
- JDK 17
- Gradle 8.9（由 GitHub Actions 安装）
- Android Gradle Plugin 8.7.3
- compileSdk / targetSdk 35，minSdk 26

## 注意
此压缩包是 Android Studio/Gradle 源码工程，不是 APK。必须在 GitHub Actions 成功构建后才能获得可安装 APK。此环境未配置 Android SDK，尚未完成实际 APK 编译和真机验证。
