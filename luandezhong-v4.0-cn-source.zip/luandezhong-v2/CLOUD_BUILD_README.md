# 云端编译步骤（手机操作）

1. 在 GitHub 打开你之前创建的 `luandezhong-v4` 仓库。
2. 如果仓库里有旧版工程文件，先备份或删除旧文件。
3. 解压本 ZIP，把 `luandezhong-v2` 目录内的所有内容上传到仓库根目录；务必包含隐藏目录 `.github/workflows/`。不要只上传 ZIP 文件。
4. 打开仓库顶部 **Actions**。如果出现启用工作流提示，先点击启用。
5. 左侧选择 **Build 乱的钟 Android APK**，点击 **Run workflow**，再点绿色确认按钮。
6. 等待运行结果变成绿色成功。进入该次运行记录，向下找到 **Artifacts**，下载 `luandezhong-v4-debug-apk`。
7. 在手机“我的文件”中解压下载包，点击 `app-debug.apk` 安装。首次安装可能需要允许浏览器或文件管理器“安装未知应用”。

如果 Actions 变红，请截取失败页面最底部的错误日志发来，我可以按报错继续修复。
