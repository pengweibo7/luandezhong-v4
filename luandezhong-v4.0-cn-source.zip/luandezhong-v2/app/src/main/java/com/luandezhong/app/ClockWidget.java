package com.luandezhong.app;

import android.appwidget.*;
import android.content.*;
import android.graphics.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class ClockWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            RemoteViews views = new RemoteViews(c.getPackageName(), R.layout.widget_placeholder);
            views.setImageViewBitmap(R.id.widget_canvas, render(c));
            Intent launch = new Intent(c, MainActivity.class);
            PendingIntent pi = PendingIntent.getActivity(c, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.widget_canvas, pi);
            manager.updateAppWidget(id, views);
        }
    }

    private Bitmap render(Context c) {
        final int w=800, h=600;
        Bitmap bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(bitmap);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        // ARGB_8888 bitmap remains transparent: no background is painted. 
        SharedPreferences pref=c.getSharedPreferences("luandezhong",0);
        String[] labels=new String[4];
        Date now=new Date();
        labels[0]=new SimpleDateFormat(pref.getBoolean("24h",true)?"HH:mm":"hh:mm a",Locale.getDefault()).format(now);
        labels[1]=new SimpleDateFormat("EEEE",Locale.CHINA).format(now);
        labels[2]=new SimpleDateFormat("yyyy年M月d日",Locale.CHINA).format(now);
        String forecast=pref.getString("forecast","");
        String[] lines=forecast.split("\\n");
        for(int i=0;i<4;i++){
            float x=pref.getFloat("x"+i,new float[]{.08f,.08f,.08f,.08f}[i])*w;
            float y=pref.getFloat("y"+i,new float[]{.14f,.31f,.40f,.50f}[i])*h;
            int[] defaults=MainActivity.PALETTES[pref.getInt("p"+i,0)];
            int a=pref.getInt("ca"+i,defaults[0]), b=pref.getInt("cb"+i,defaults[1]);
            int size=pref.getInt("s"+i,new int[]{48,20,20,18}[i]);
            p.setTextSize(size*(i==3?1.45f:1.8f));
            p.setTypeface(Typeface.create(i==0?"sans-serif":"sans-serif-medium",i==0?Typeface.BOLD:Typeface.NORMAL));
            int dir=pref.getInt("dir"+i,0);
            float x1=x, y1=y-size*1.8f;
            float x2=dir==1?x+size*6:x+size*6, y2=dir==2?y:y-size*1.8f;
            p.setShader(new LinearGradient(x1,y1,x2,y2,a,b,Shader.TileMode.CLAMP));
            if(i==3){
                float lineHeight=(size+5)*1.55f;
                if(lines.length<=1) canvas.drawText("设置城市后显示七天天气",x,y,p);
                else { canvas.drawText(lines[0],x,y,p); for(int j=1;j<lines.length && j<=7;j++) canvas.drawText(lines[j],x,y+j*lineHeight,p); }
            } else canvas.drawText(labels[i],x,y,p);
            p.setShader(null);
        }
        return bitmap;
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context,intent);
        String action=intent.getAction();
        if(Intent.ACTION_TIME_CHANGED.equals(action)||Intent.ACTION_TIMEZONE_CHANGED.equals(action)||Intent.ACTION_DATE_CHANGED.equals(action)){
            AppWidgetManager manager=AppWidgetManager.getInstance(context);
            int[] ids=manager.getAppWidgetIds(new ComponentName(context,ClockWidget.class));
            onUpdate(context,manager,ids);
        }
    }
}
