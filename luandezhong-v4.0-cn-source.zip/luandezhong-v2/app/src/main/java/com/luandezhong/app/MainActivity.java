package com.luandezhong.app;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.appwidget.AppWidgetManager;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.location.Geocoder;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final String PREF="luandezhong";
    static final String[] ITEMS={"时间","星期","日期","天气"};
    public static final int[][] PALETTES={{0xFF8EA2FF,0xFFB58CFF},{0xFF35C7B5,0xFF6487F5},{0xFFFFA66B,0xFFEF6F91},{0xFFB7D6FF,0xFF7A8CE8}};
    Preview preview; TextView weatherText; EditText cityInput; int selected=0; int palette=0; int size=48;
    ExecutorService pool=Executors.newSingleThreadExecutor();
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(0xFFF4F5FA); getWindow().setNavigationBarColor(0xFFF4F5FA); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(20),dp(20),dp(12)); root.setBackgroundColor(0xFFF4F5FA); setContentView(root);
        TextView title=new TextView(this); title.setText("乱的钟"); title.setTextSize(28); title.setTextColor(0xFF171923); title.setTypeface(null,1); root.addView(title);
        TextView sub=new TextView(this); sub.setText("桌面时钟 · 天气 · 自由排版"); sub.setTextColor(0xFF74798A); sub.setTextSize(13); root.addView(sub);
        preview=new Preview(this); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,0,1); pp.topMargin=dp(18); pp.bottomMargin=dp(12); root.addView(preview,pp);
        TextView hint=new TextView(this); hint.setText("在预览中拖动元素即可调整位置"); hint.setTextColor(0xFF777D8D); hint.setTextSize(12); root.addView(hint);
        HorizontalScrollView hsv=new HorizontalScrollView(this); LinearLayout tabs=new LinearLayout(this); hsv.addView(tabs); root.addView(hsv); for(int i=0;i<4;i++){final int k=i; Button btn=button(ITEMS[i]); btn.setOnClickListener(v->{selected=k; size=getPrefs().getInt("s"+k, k==0?48: k==3?18:20); preview.invalidate(); refreshSizeLabel();}); tabs.addView(btn);}
        TextView sl=new TextView(this); sl.setText("元素大小"); sl.setTextColor(0xFF252A38); sl.setPadding(0,dp(10),0,0); root.addView(sl);
        SeekBar seek=new SeekBar(this); seek.setMax(90); seek.setProgress(size-10); root.addView(seek); seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){if(u){size=p+10;getPrefs().edit().putInt("s"+selected,size).apply();preview.invalidate();syncWidget();}} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}});
        TextView colors=new TextView(this); colors.setText("渐变配色"); colors.setTextColor(0xFF252A38); root.addView(colors); LinearLayout swatches=new LinearLayout(this); root.addView(swatches); for(int i=0;i<PALETTES.length;i++){final int k=i; Button c=button("●"); c.setTextColor(PALETTES[i][0]); c.setTextSize(24); c.setOnClickListener(v->{palette=k;getPrefs().edit().putInt("p"+selected,k).apply();preview.invalidate();syncWidget();}); swatches.addView(c);}
        LinearLayout hexRow=new LinearLayout(this); hexRow.setOrientation(LinearLayout.HORIZONTAL); root.addView(hexRow);
        EditText colorStart=new EditText(this); colorStart.setSingleLine(true); colorStart.setHint("#8EA2FF"); colorStart.setTextSize(12); colorStart.setText(getHex(getPrefs().getInt("ca"+selected,PALETTES[0][0]))); hexRow.addView(colorStart,new LinearLayout.LayoutParams(0,dp(48),1));
        EditText colorEnd=new EditText(this); colorEnd.setSingleLine(true); colorEnd.setHint("#B58CFF"); colorEnd.setTextSize(12); colorEnd.setText(getHex(getPrefs().getInt("cb"+selected,PALETTES[0][1]))); hexRow.addView(colorEnd,new LinearLayout.LayoutParams(0,dp(48),1));
        Button applyColors=button("应用 HEX 颜色"); root.addView(applyColors);
        applyColors.setOnClickListener(v->{try{int a=Color.parseColor(colorStart.getText().toString().trim());int b=Color.parseColor(colorEnd.getText().toString().trim());getPrefs().edit().putInt("ca"+selected,a).putInt("cb"+selected,b).apply();preview.invalidate();syncWidget();Toast.makeText(this,"渐变颜色已应用",Toast.LENGTH_SHORT).show();}catch(Exception ex){Toast.makeText(this,"颜色格式错误，请使用 #RRGGBB",Toast.LENGTH_SHORT).show();}});
        Button direction=button("切换渐变方向"); root.addView(direction);
        direction.setOnClickListener(v->{int d=(getPrefs().getInt("dir"+selected,0)+1)%3;getPrefs().edit().putInt("dir"+selected,d).apply();preview.invalidate();syncWidget();String[] names={"左上至右下","横向","纵向"};Toast.makeText(this,"渐变方向："+names[d],Toast.LENGTH_SHORT).show();});

        cityInput=new EditText(this); cityInput.setSingleLine(true); cityInput.setText(getPrefs().getString("city","北京")); cityInput.setHint("输入中国城市，例如：北京、上海、广州"); root.addView(cityInput);
        EditText qKey=new EditText(this); qKey.setSingleLine(true); qKey.setText(getPrefs().getString("qweather_key","")); qKey.setHint("和风天气 API Key（可选；优先国内天气）"); root.addView(qKey);
        Button saveKey=button("保存国内天气 API Key"); root.addView(saveKey); saveKey.setOnClickListener(v->{getPrefs().edit().putString("qweather_key",qKey.getText().toString().trim()).apply();Toast.makeText(this,"已保存；更新天气时优先尝试国内天气源",Toast.LENGTH_SHORT).show();});
        Button load=button("保存城市并更新七天天气"); root.addView(load); load.setOnClickListener(v->{String city=cityInput.getText().toString().trim(); if(city.isEmpty())return;getPrefs().edit().putString("city",city).apply();fetchWeather(city);});
        Button locate=button("使用当前位置（需授权）"); root.addView(locate); locate.setOnClickListener(v->requestLocation());
        Button hourMode=button("切换 12 / 24 小时制"); root.addView(hourMode); hourMode.setOnClickListener(v->{boolean next=!getPrefs().getBoolean("24h",true);getPrefs().edit().putBoolean("24h",next).apply();preview.invalidate();syncWidget();Toast.makeText(this,next?"已切换为 24 小时制":"已切换为 12 小时制",Toast.LENGTH_SHORT).show();});
        TextView locationHint=new TextView(this); locationHint.setText("城市可手动输入中文名称。定位功能需要你主动授权位置权限；拒绝授权不影响手动搜索天气。"); locationHint.setTextColor(0xFF646B7B); locationHint.setTextSize(11); root.addView(locationHint);
        weatherText=new TextView(this); weatherText.setText("天气使用 Open-Meteo 免费天气数据；首次使用请设置城市。"); weatherText.setTextColor(0xFF646B7B); weatherText.setTextSize(12); weatherText.setPadding(0,dp(6),0,dp(6)); root.addView(weatherText);
        fetchWeather(getPrefs().getString("city","北京"));
    }
    void requestLocation(){new AlertDialog.Builder(this).setTitle("位置权限说明").setMessage("仅在你点击“使用当前位置”时申请大致位置权限，用于反查城市并获取天气。不会在后台持续定位；你也可以拒绝授权，继续手动输入中文城市名称。") .setNegativeButton("暂不使用",(d,w)->{}).setPositiveButton("继续",(d,w)->{if(android.os.Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},501);}else useLastLocation();}).show();}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==501){if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)useLastLocation();else Toast.makeText(this,"未获得位置权限，可继续手动搜索城市",Toast.LENGTH_LONG).show();}}
    void useLastLocation(){try{LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);Location best=null;for(String provider:lm.getProviders(true)){Location l=lm.getLastKnownLocation(provider);if(l!=null&&(best==null||l.getTime()>best.getTime()))best=l;}if(best==null){Toast.makeText(this,"暂时没有可用定位，请开启定位服务或手动输入城市",Toast.LENGTH_LONG).show();return;}Geocoder geocoder=new Geocoder(this,java.util.Locale.CHINA);java.util.List<android.location.Address> addresses=geocoder.getFromLocation(best.getLatitude(),best.getLongitude(),1);if(addresses!=null&&!addresses.isEmpty()){String city=addresses.get(0).getLocality();if(city==null||city.isEmpty())city=addresses.get(0).getAdminArea();if(city!=null&&!city.isEmpty()){cityInput.setText(city);getPrefs().edit().putString("city",city).apply();fetchWeather(city);return;}}Toast.makeText(this,"无法识别所在城市，请手动输入城市名称",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"定位失败，请检查定位服务或手动输入城市",Toast.LENGTH_LONG).show();}}
    android.content.SharedPreferences getPrefs(){return getSharedPreferences(PREF,0);} int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);} Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(12);return b;} void refreshSizeLabel(){}
    String getHex(int color){return String.format(java.util.Locale.US,"#%06X",(0xFFFFFF & color));}
    void syncWidget(){android.appwidget.AppWidgetManager m=android.appwidget.AppWidgetManager.getInstance(this);int[] ids=m.getAppWidgetIds(new android.content.ComponentName(this,ClockWidget.class));if(ids.length>0)new ClockWidget().onUpdate(this,m,ids);}
    void fetchWeather(String city){weatherText.setText("正在获取 "+city+" 的天气…"); pool.execute(()->{String result=null;String source="";try{String key=getPrefs().getString("qweather_key","").trim();if(!key.isEmpty()){try{String geo=get("https://geoapi.qweather.com/v2/city/lookup?location="+URLEncoder.encode(city,"UTF-8")+"&key="+URLEncoder.encode(key,"UTF-8")+"&number=1");JSONObject root=new JSONObject(geo);if(!"200".equals(root.optString("code")))throw new Exception("国内城市查询失败");String location=root.getJSONArray("location").getJSONObject(0).getString("id");String data=get("https://devapi.qweather.com/v7/weather/7d?location="+location+"&key="+URLEncoder.encode(key,"UTF-8"));JSONObject dailyRoot=new JSONObject(data);if(!"200".equals(dailyRoot.optString("code")))throw new Exception("国内天气接口不可用");JSONArray days=dailyRoot.getJSONArray("daily");StringBuilder out=new StringBuilder(city+" · 未来七天（国内天气）\n");for(int i=0;i<days.length()&&i<7;i++){JSONObject d=days.getJSONObject(i);String date=d.optString("fxDate");if(date.length()>=10)date=date.substring(5);out.append(date).append("  ").append(d.optString("textDay","天气" )).append("  ").append(d.optString("tempMax","--")).append("° / ").append(d.optString("tempMin","--")).append("°\n");}result=out.toString();source="和风天气";}catch(Exception domesticError){result=null;}}if(result==null){String geo=get("https://geocoding-api.open-meteo.com/v1/search?name="+URLEncoder.encode(city,"UTF-8")+"&count=1&language=zh&format=json");JSONObject places=new JSONObject(geo);if(!places.has("results")||places.getJSONArray("results").length()==0)throw new Exception("未找到该城市");JSONObject place=places.getJSONArray("results").getJSONObject(0);double lat=place.getDouble("latitude"),lon=place.getDouble("longitude");String data=get("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=7&timezone=auto");JSONObject daily=new JSONObject(data).getJSONObject("daily");JSONArray dates=daily.getJSONArray("time"),max=daily.getJSONArray("temperature_2m_max"),min=daily.getJSONArray("temperature_2m_min"),codes=daily.getJSONArray("weather_code");StringBuilder out=new StringBuilder(city+" · 未来七天（备用天气）\n");for(int i=0;i<dates.length();i++)out.append(dates.getString(i).substring(5)).append("  ").append(weatherName(codes.getInt(i))).append("  ").append(Math.round(max.getDouble(i))).append("° / ").append(Math.round(min.getDouble(i))).append("°\n");result=out.toString();source="Open-Meteo 备用源";}final String finalResult=result;final String finalSource=source;getPrefs().edit().putString("forecast",finalResult).apply();AppWidgetManager manager=AppWidgetManager.getInstance(this);int[] widgetIds=manager.getAppWidgetIds(new ComponentName(this,ClockWidget.class));if(widgetIds.length>0)new ClockWidget().onUpdate(this,manager,widgetIds);runOnUiThread(()->{weatherText.setText(finalResult+"数据源："+finalSource);preview.invalidate();});}catch(Exception e){runOnUiThread(()->weatherText.setText("天气获取失败：请检查网络或城市名称；如使用国内天气源，请检查 API Key。"));}}); }
    String get(String u)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(10000);try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()))){StringBuilder b=new StringBuilder();String l;while((l=r.readLine())!=null)b.append(l);return b.toString();}finally{c.disconnect();}}
    String weatherName(int c){if(c==0)return "晴";if(c<=3)return "多云";if(c<=48)return "雾";if(c<=67)return "雨";if(c<=77)return "雪";if(c<=82)return "阵雨";return "雷雨";}
    class Preview extends View {Paint p=new Paint(3);float downX,downY;int dragging=-1;
        android.view.ScaleGestureDetector scaleDetector;float[] xs={.08f,.08f,.08f,.08f},ys={.14f,.31f,.40f,.50f};String[] labels={"","星期日","2026年11月20日","未来七天"}; Preview(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);
            scaleDetector=new android.view.ScaleGestureDetector(c,new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){
                @Override public boolean onScale(android.view.ScaleGestureDetector detector){
                    int current=getPrefs().getInt("s"+selected,selected==0?48:selected==3?18:20);
                    int next=Math.max(10,Math.min(100,Math.round(current*detector.getScaleFactor())));
                    getPrefs().edit().putInt("s"+selected,next).apply();invalidate();return true;
                }});
            for(int i=0;i<4;i++){xs[i]=getPrefs().getFloat("x"+i,xs[i]);ys[i]=getPrefs().getFloat("y"+i,ys[i]);}} protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setShader(new LinearGradient(0,0,w,h,0xFF17243D,0xFF35436C,Shader.TileMode.CLAMP));c.drawRoundRect(0,0,w,h,dp(28),dp(28),p);p.setShader(null);p.setColor(0x55FFFFFF);p.setTextSize(dp(12));c.drawText("ONE UI  ·  LIVE PREVIEW",dp(20),dp(28),p);java.util.Date now=new java.util.Date();
            labels[0]=new java.text.SimpleDateFormat(getPrefs().getBoolean("24h",true)?"HH:mm":"hh:mm a",java.util.Locale.getDefault()).format(now);
            labels[1]=new java.text.SimpleDateFormat("EEEE",java.util.Locale.CHINA).format(now);
            labels[2]=new java.text.SimpleDateFormat("yyyy年M月d日",java.util.Locale.CHINA).format(now);
            for(int i=0;i<4;i++){int pal=getPrefs().getInt("p"+i,0);int ca=getPrefs().getInt("ca"+i,PALETTES[pal][0]), cb=getPrefs().getInt("cb"+i,PALETTES[pal][1]);int sz=getPrefs().getInt("s"+i,i==0?48:i==3?18:20);float x=xs[i]*w,y=ys[i]*h;int dir=getPrefs().getInt("dir"+i,0);
                float gx=dir==1?x+dp(sz*3):x, gy=dir==2?y-dp(sz):y-dp(sz);
                float ex=dir==1?x+dp(sz*3):x+dp(sz*3), ey=dir==2?y:y;
                p.setShader(new LinearGradient(gx,gy,ex,ey,ca,cb,Shader.TileMode.CLAMP));p.setTextSize(dp(sz));p.setTypeface(i==0?Typeface.create("sans-serif",Typeface.BOLD):Typeface.create("sans-serif-medium",Typeface.NORMAL));String txt=labels[i];if(i==3){
                    String f=getPrefs().getString("forecast","");
                    String[] lines=f.isEmpty()?new String[]{"设置城市后显示七天天气"}:f.split("\\n");
                    float lineH=dp(Math.max(17,sz+5));
                    if(lines.length==1) c.drawText(lines[0],x,y,p); else for(int j=1;j<lines.length && j<=7;j++) c.drawText(lines[j],x,y+(j-1)*lineH,p);
                } else c.drawText(txt,x,y,p);
                p.setShader(null);if(i==selected){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0x99FFFFFF);float boxBottom=y+dp(10);
                if(i==3) boxBottom=y+dp((sz+5)*7);
                c.drawRoundRect(x-dp(8),y-dp(sz+8),x+Math.max(dp(150),p.measureText(txt))+dp(8),boxBottom,dp(10),dp(10),p);p.setStyle(Paint.Style.FILL);}}postInvalidateDelayed(30000);}
        public boolean onTouchEvent(android.view.MotionEvent e){
            scaleDetector.onTouchEvent(e);
            float x=e.getX(),y=e.getY();if(e.getAction()==0){downX=x;downY=y;float best=Float.MAX_VALUE;for(int i=0;i<4;i++){float d=(x-xs[i]*getWidth())*(x-xs[i]*getWidth())+(y-ys[i]*getHeight())*(y-ys[i]*getHeight());if(d<best){best=d;dragging=i;}}selected=dragging;invalidate();return true;}if(e.getAction()==1){getPrefs().edit().putFloat("x"+selected,xs[selected]).putFloat("y"+selected,ys[selected]).apply();syncWidget();return true;}if(e.getAction()==2&&dragging>=0&&!scaleDetector.isInProgress()&&e.getPointerCount()==1){xs[dragging]=Math.max(.02f,Math.min(.78f,x/getWidth()));ys[dragging]=Math.max(.08f,Math.min(.94f,y/getHeight()));invalidate();return true;}return true;}
    }
}
